import boto3

def get_ec2_details(event):

    #grab standard details 
    account_number = event.get('account')
    region = event.get('region')
    alert_time = event.get('time')
    resouce =   details.get("resource")[0]

    #grab details of event
    details = event.get('detail')
    
    instance_id  = details.get('instance-id')
    state = details.get('state')

    ec2_client = boto3.client('ec2')
    try:

        response = ec2_client.describe_instances(
                InstanceIds=[instance_id]
        )

        instance = response['Reservations'][0]['Instances'][0]
        reason = instance.get('StateTransitionReason')

        message_blocks = [
        {
            "type": "header",
            "text": {
                "type": "plain_text",
                "text": "🚨 EC2 Instance State Change"
            }
        },
        {
            "type": "section",
            "fields": [
                {
                    "type": "mrkdwn",
                    "text": f"*Account Number:*\n{account_number}"
                },

                {
                    "type": "mrkdwn",
                    "text": f"*Region:*\n{region}"
                },
                {
                    "type": "mrkdwn",
                    "text": f"*Alert Time:*\n{alert_time}"
                },
                {
                    "type": "mrkdwn",
                    "text": f"*Resource:*\n{resouce}"
                },

                {
                    "type": "mrkdwn",
                    "text": f"*Instance ID:*\n{instance_id}"
                },
                {
                    "type": "mrkdwn",
                    "text": f"*New State:*\n{state}"
                },
                {
                    "type": "mrkdwn",
                    "text": f"*New State:*\n{reason}"
                }

            ]
        }
        ]
    
        return message_blocks
    
    except Exception as e:
        return(f"error getting details for {instance_id}")