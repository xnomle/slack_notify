import requests
import os
import json
import boto3
import sys
from modules.ec2 import get_ec2_details

REGION = os.getenv("ap-southeast-2")
SLACK_CHANNELS = {} 
SLACK_BOT_TOKEN = os.getenv("SLACK_BOT_TOKEN")
COMPLY_ADVANTAGE_SECRET_ARN = os.getenv("COMPLY_ADVANTAGE_SECRET_ARN")

def load_slack_channel_ids():
    global SLACK_CHANNELS
    try:
        client = boto3.client('secretsmanager', region_name=REGION)

        secret_response = client.get_secret_value(
            SecretId="arn:aws:secretsmanager:ap-southeast-2:078689321816:secret:slack_notify/SLACK_BOT_TOKEN20251129043443608900000001-fT4Pmb"
        )
        # load the secret as a python dictionary 
        SLACK_CHANNELS = json.loads(secret_response['SecretString'])
        
        print("Slack channels loaded successfully into global variables.")

    except Exception as e:
        print(f" FATAL: Could not retrieve secrets. {e}")
        sys.exit(1)    

def get_ecs_details():
    pass
             
def get_cloudwatch_details():
    pass

def send_slack_message(SLACK_BOT_TOKEN, message_block):
    url = "https://slack.com/api/chat.postMessage"
    slack_channel_id = SLACK_CHANNELS["it-test-channel"]

    headers = {
        "Authorization": f"Bearer {SLACK_BOT_TOKEN}",
        "Content-Type": "application/json; charset=utf-8"
    }

    payload = {
        "channel": slack_channel_id,
        "username": "ZenBot",
        "text": message_block
    }
   
    response = requests.post(url, headers=headers, json=payload)
    response_data = response.json()
    print(response_data)

def lambda_handler(event, context):
    print(f"Received event: {json.dumps(event)}")

    # pull alert type 
    source = event.get('source')

    # grab details of event and pass to function. 

    if "EC2" in source:
        message_block = get_ec2_details(event)
    elif "ECS" in source: 
        message_block = get_ecs_details(details)
    else: 
        message_block = get_cloudwatch_details(details)

    send_slack_message(SLACK_BOT_TOKEN, message_block)

    return {
        'statusCode': 200,
        'body': json.dumps('Message posted to Slack!')
    }